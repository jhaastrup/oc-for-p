<?php
// Heading
$_['heading_title']       = 'Ship With Sendbox';
