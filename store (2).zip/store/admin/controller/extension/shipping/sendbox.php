<?php
class Sendbox_Shipping_API{
    //make a post to sendbox api using curl.
    public function post_on_api_by_curl($url, $data, $api_key)
    {
        $ch = curl_init($url);
        // Setup request to send json via POST.
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json', 'Authorization:' . $api_key));
        // Return response instead of printing.
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        // Send request.
        $result = curl_exec($ch);
        curl_close($ch);
        // Print response.
        return $result;
    }

    //make a get request using curl to sendbox

    public function get_api_response_by_curl($url)
    {
        $handle = curl_init();
        curl_setopt($handle, CURLOPT_URL, $url);
        curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
        $output = curl_exec($handle);
        curl_close($handle);
        return $output;
    }
    //make request to sendbox with header

    public function get_api_response_with_header($url, $request_headers){
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $request_headers);
        $season_data = curl_exec($ch);
        if (curl_errno($ch)) {
            print "Error: " . curl_error($ch);
            exit();
        }
        // Show me the result
        curl_close($ch);
        return $season_data;

    }


    //all sendbox endpoints
    public function get_sendbox_api_url($url_type)
    {
        if ('delivery_quote' == $url_type) {
            $url = 'https://api.sendbox.ng/v1/merchant/shipments/delivery_quote';
        } elseif ('countries' == $url_type) {
            $url = 'https://api.sendbox.co/auth/countries?page_by={' . '"per_page"' . ':264}';
        } elseif ('states' == $url_type) {
            $url = 'https://api.sendbox.co/auth/states';
        } elseif ('shipments' == $url_type) {
            $url = 'https://api.sendbox.ng/v1/merchant/shipments';
        } elseif ('item_type' == $url_type) {
            $url = 'https://api.sendbox.ng/v1/item_types';
        } elseif ('profile' == $url_type) {
            $url = 'https://api.sendbox.co/oauth/profile';
        }else {
            $url = '';
        }
        return $url;
    }

}

class ControllerExtensionShippingSendbox extends Controller { 
     
    private $error = array();

    public function index()
    { 
        $this->db->query("CREATE TABLE IF NOT EXISTS " . DB_PREFIX . "sendbox (
            id INT NOT NULL AUTO_INCREMENT PRIMARY KEY, 
            sendbox_key VARCHAR(225),
           sendbox_values VARCHAR(225)
             ) ENGINE = INNODB;");
    
         
        if($this->request->server['REQUEST_METHOD'] == 'GET'){
            $urlObj = $_GET;
            if(isset($urlObj)){
                $app_id =preg_replace('/\s/','',$urlObj['app_id']);
                $client_secret = preg_replace('/\s/','', $urlObj['client_secret']); 


                
                $columns = array('id','sendbox_key', 'sendbox_values');
                $values = array( NULL, 'sendbox_app_id', $app_id);
    
                 $value_client_secret = array(NULL, 'sendbox_client_secret', $client_secret);
                  $this->save_data($columns, $values);
                  $this->save_data($columns, $value_client_secret); 
            }
        }
        $static_url = HTTP_SERVER."controller/extension/shipping/sendbox-webhook.php";
        $sendbox_obj = new Sendbox_Shipping_API();

        $this->load->language('extension/shipping/sendbox');

        $this->document->setTitle($this->language->get('heading_title'));

        $this->load->model('setting/setting'); 

        if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
            $this->model_setting_setting->editSetting('shipping_sendbox', $this->request->post);

            $this->session->data['success'] = $this->language->get('text_success');

            $this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token']. '&type=shipping', true));
        }


        if (isset($this->error['warning'])) {
            $data['error_warning'] = $this->error['warning'];
        } else {
            $data['error_warning'] = '';
        }

        if (isset($this->error['keys'])) {
            $data['error_keys'] = $this->error['keys'];
        } else {
            $data['error_keys'] = '';
        } 

        //load the breadcrumbs

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_shipping'),
            'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'].'&type=shipping', true)
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('extension/shipping/sendbox', 'user_token=' . $this->session->data['user_token'], true)
        ); 

        $data['action'] = $this->url->link('extension/shipping/sendbox', 'user_token=' . $this->session->data['user_token'], true);

        $data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=shipping', true);
        $data['sendbox_status'] = $this->config->get('shipping_sendbox_status');
        $data['shipping_sendbox_geo_zone_id'] = $this->config->get('shipping_sendbox_geo_zone_id');
        
        if (isset($this->request->post['shipping_sendbox_geo_zone_id'])) {
            $data['shipping_sendbox_geo_zone_id'] = $this->request->post['shipping_sendbox_geo_zone_id'];
        }

        if (isset($this->request->post['shipping_sendbox_status'])) {
            $data['shipping_sendbox_status'] = $this->request->post['shipping_sendbox_status'];
        }

        //getstates
        $url = 'https://api.sendbox.co/auth/states?page_by={' . '"per_page"' . ':264}&filter_by={'.'"country_code"'.':"NG"'.'}';
        $nigeria_states = $sendbox_obj->get_api_response_by_curl($url);
        $nigeria_states = json_decode($nigeria_states)->results;
        //$nigeria_states = $this->config->get('sendbox_state');
       
       /*  $data['sendbox_state'] =$nigeria_states;
        if(isset($this->request->post['sendbox_state'])){
            $data['sendbox_state'] = $this->request->post['sendbox_state'];
        } */ 


        $this->load->model('localisation/zone');
		$zone_info = $this->model_localisation_zone->getZone($this->config->get('config_zone_id'));

        if(isset($this->request->post['sendbox_state'])){
            $data['sendbox_state'] = $this->request->post['sendbox_state'];
        }else{
            $data['sendbox_state'] =  $zone_info['name'];
        }



        //getname,phone and email..to get this, we make a call kinda a long process but we move
        //get the add_id and client secret then build a sendbox url
        $server_obj = $_SERVER;
        $scopes= "profile"; 
        $user_token = $server_obj["QUERY_STRING"];
        parse_str($user_token, $output);
        $token = $output['user_token'];
        $_url = $server_obj["PHP_SELF"];
        $domain = $server_obj["HTTP_HOST"];
        $domain_name = $domain.$_url;

        $http_scheme = $server_obj['HTTPS'];
        $http_sch = "http://";
        if ($http_scheme){
            $http_sch = "https://";
        }

        $route = $output['route'];
      
        $state_params =  $http_sch.$domain_name.'?route='.$route.'&user_token='.$token.'&app_id='.$app_id.'&client_secert'.$client_secret;
         
         $new_state_params = str_replace('&', '$', $state_params);
         
        $sendbox_url = 'https://api.sendbox.co/oauth/access?app_id='.$app_id.'&scopes='.$scopes.'&redirect_url='.$static_url.'&state='.$new_state_params;
         //after connecting, now get code and make a new url to get authtoken

        
        $get_code = "";
        if (isset($_GET['code'])){
            $query = parse_str($server_obj["QUERY_STRING"], $get_code);
            $get_code = $query.$_GET["code"];
        } 
        $s_url = 'https://api.sendbox.co/oauth/access/access_token?';
        $url_oauth = $s_url.'app_id='.$app_id.'&redirect_url='.$static_url.'&client_secret='.$client_secret.'&code='.$get_code.'';
        $oauth_res = $sendbox_obj->get_api_response_by_curl($url_oauth);
        $oauth_obj = json_decode($oauth_res);

        $oauth_token = ""; 
        $refresh_token = ""; 
        
        if(isset($oauth_obj->access_token)){
            $oauth_token = $oauth_obj->access_token;
        }
        if(isset($oauth_obj->refresh_token)){
            $refresh_token = $oauth_obj->refresh_token;
        }
        if($oauth_token  != null && $refresh_token !=null){
            $auth_values = array( NULL, 'auth_token', $oauth_token);
         $refresh_values = array(NULL, 'refresh_token', $refresh_token);
         $this->save_data($columns, $auth_values);
         $this->save_data($columns, $refresh_values);
        }
       //$auth_token = $oauth_obj->access_token;
        //$refresh_token = $oauth_obj->refresh_token;
         //$auth_values = array( NULL, 'auth_token', $auth_token);
         //$refresh_values = array(NULL, 'refresh_token', $refresh_token);
         //$this->save_data($columns, $auth_values);
         //$this->save_data($columns, $refresh_token);

        var_dump($oauth_obj);
        
        $oauth = "";
        if(isset($oauth_obj->access_token)){
             $oauth = $oauth_obj->access_token;
        }

        //FINALLY CALL PROFILE FOR PROFILE DETAILS

        if( $oauth != null){
            $auth_header = $oauth;
            $type = "application/json";
    
            $request_headers = array(
                "Content-Type: " .$type,
                "Authorization: " .$auth_header, 
            );
            $profile_url = $sendbox_obj->get_sendbox_api_url('profile');
            $profile_res = $sendbox_obj->get_api_response_with_header($profile_url,$request_headers);
    
    
            $profile_obj = json_decode($profile_res);
            $sendbox_username = $profile_obj->name;
            $sendbox_phone =$profile_obj->phone;
            $sendbox_email = $profile_obj->email;
            //save into the db

            //$columns = array('id','sendbox_key', 'sendbox_values');
            $name_values = array( NULL, 'sendbox_username', $sendbox_username);
            $phone_values = array(NULL, 'sendbox_phone', $sendbox_phone);
            $email_values = array(NULL, 'sendbox_email', $sendbox_email);

            $this->save_data($columns, $name_values);
            $this->save_data($columns, $email_values);
            $this->save_data($columns, $phone_values); 
            $data['sendbox_username'] = $this->get_data('sendbox_username')->row['sendbox_values'];
            $data['sendbox_email'] = $this->get_data('sendbox_email')->row['sendbox_values'];
            $data['sendbox_phone'] = $this->get_data('sendbox_phone')->row['sendbox_values'];
            $data['sendbox_country'] = "Nigeria";


            if(isset($this->request->post['sendbox_username'])){
                $data['sendbox_username'] = $this->request->post['sendbox_username'];
            }
        
            if(isset($this->request->post['sendbox_phone'])){
                $data['sendbox_phone'] = $this->request->post['sendbox_phone'];
            }
    
            if(isset($this->request->post['sendbox_email'])){
                $data['sendbox_email'] = $this->request->post['sendbox_email'];
            }
        }
        
 
       

        if(isset($this->request->post['sendbox_store_address'])){
            $data['sendbox_store_address'] = $this->request->post['sendbox_store_address'];
        }else{
            $data['sendbox_store_address'] =  $this->config->get('config_address');
        }

        if (isset($this->request->post['shipping_sendbox_sort_order'])) {
			$data['shipping_sendbox_sort_order'] = $this->request->post['shipping_sendbox_sort_order'];
		} else {
			$data['shipping_sendbox_sort_order'] = $this->config->get('shipping_sendbox_sort_order');
        }

         if(isset($this->request->post['sendbox_rates'])){
            $data['senbox_rates'] = $this->request->post['sendbox_rates'];
        }else{
            $data['sendbox_rates'] = array('minimum', 'maximum');
        }

        if(isset($this->request->post['sendbox_pickup_types'])){

            $data['senbox_pickup_types'] = $this->request->post['sendbox_pickup_types'];
        }else{
            $data['sendbox_pickup_types'] = array('pickup', 'drop-off');
        
        } 

        if(isset($this->request->post['sendbox_country'])){
            $data['sendbox_country'] = $this->request->post['sendbox_country'];
        }else{
            $data['sendbox_country'] = "Nigeria";
        }

        
       
        $data['static_url'] = $static_url;
       
        $data['sendbox_url'] = $sendbox_url;
        
        //load opencart zones 
        $this->load->model('localisation/geo_zone');
		$data['geo_zones'] = $this->model_localisation_geo_zone->getGeoZones();


        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');
       
        //load everything into view.
        $this->response->setOutput($this->load->view('extension/shipping/sendbox', $data));
    }


    

    //validate form

    private function validate()
    {
        if (!$this->user->hasPermission('modify', 'extension/shipping/sendbox')) {
            $this->error['warning'] = $this->language->get('error_permission');
        }

        return !$this->error;
    }

    //save into db
    
    private function save_data($columns, $values){ 
        // $db_obj =  $this->get_data($values[1]);
       
         //if ($db_obj->num_rows >=1){
         // $id= $db_obj->row['id']; 
          //$query = "UPDATE `".DB_PREFIX."sendbox` SET `sendbox_values` =`".$values[2]."` WHERE `".DB_PREFIX."sendbox`.`id` = ".$id.";";
         // $query2 = "UPDATE `".DB_PREFIX."sendbox` SET `sendbox_key` =`".$values[1]."` WHERE `".DB_PREFIX."sendbox`.`id` = ".$id.";";
         //$query = "DELETE FROM '".DB_PREFIX."sendbox' WHERE '".DB_PREFIX."sendbox'.'id' = ".$id.";";
          //$this->db->query($query);
        //  $this->db->query($query2);
       // } 
         $query = "INSERT INTO " . DB_PREFIX . "sendbox (" . implode(" ,", $columns). ") VALUES ('" . implode("','", $values) . "');";
        $exec = $this->db->query($query);
       
        return $exec; 
        
    } 
//get from db
    private function get_data($key){
        $query = $this->db->query("SELECT * FROM " . DB_PREFIX ."sendbox WHERE sendbox_key='". $key."';");
        return $query;

    }


}


